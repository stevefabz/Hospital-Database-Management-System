 #app.py
from flask import Flask, render_template, request, redirect, url_for, flash
import psycopg2 #pip install psycopg2
import psycopg2.extras


app = Flask(__name__)
app.secret_key = "cairocoders-ednalan"

DB_HOST =  "localhost"
DB_NAME = "HDMS"
DB_USER = "postgres"
DB_PASS = 12345

conn = psycopg2.connect(dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST)


@app.route('/')
def Index():
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    s = "SELECT * FROM patient"
    cur.execute(s) # Execute the SQL
    list_users = cur.fetchall()
    return render_template('index.html', list_users = list_users)

@app.route('/add_patient', methods=['POST'])
def add_patient():
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    if request.method == 'POST':
        first_name = request.form['first_name']
        last_name= request.form['last_name']
        address = request.form['address']
        phone = request.form['phone']
        email = request.form['email']
        age = request.form['age']
        gender = request.form['gender']
        doctor_id = request.form['doctor_id']
        cur.execute("INSERT INTO patient (first_name, last_name,address,phone,email,age,gender, doctor_id) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)", (first_name, last_name,address,phone,email,age,gender, doctor_id))
        conn.commit()
        flash('Record(s) Added successfully')
        return redirect(url_for('Index'))

@app.route('/delete/<string:patient_id>', methods = ['POST','GET'])
def delete_patient(patient_id):
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)

    cur.execute('DELETE FROM patient WHERE patient_id = {0}'.format(patient_id))
    conn.commit()
    flash('Record Removed Successfully')
    return redirect(url_for('Index'))

if __name__ == "__main__":
    app.run(debug=True)
